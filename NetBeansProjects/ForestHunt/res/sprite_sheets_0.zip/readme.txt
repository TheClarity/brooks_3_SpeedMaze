All the content in this ZIP file is lincensed under CC0.
Made by Sogomn

http://opengameart.org/users/sogomn
https://github.com/Sogomn